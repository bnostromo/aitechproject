# preprocessing.py
# Role: Loads creditcard.csv, scales features, handles class imbalance with SMOTE,
#        and produces train/test splits saved to disk for use by modelling.py.
# Run order: FIRST — before eda.py, modelling.py, evaluation.py, explainability.py

import pandas as pd
import numpy as np
import os
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE

# ── Configuration ─────────────────────────────────────────────────────────────
RANDOM_STATE = 42
TEST_SIZE = 0.2
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'creditcard.csv')
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), 'data')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Load Data ─────────────────────────────────────────────────────────────────
def load_data(path: str) -> pd.DataFrame:
    """Load the raw credit card CSV file."""
    df = pd.read_csv(path)
    print(f"[preprocessing] Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")
    print(f"[preprocessing] Class distribution:\n{df['Class'].value_counts()}")
    return df

# ── Feature Scaling ───────────────────────────────────────────────────────────
def scale_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Scale 'Time' and 'Amount' to match the range of V1-V28 (already PCA-scaled).
    V1-V28 are left as-is since they were produced by PCA transformation.
    """
    scaler = StandardScaler()
    df = df.copy()
    df['scaled_Amount'] = scaler.fit_transform(df[['Amount']])
    df['scaled_Time'] = scaler.fit_transform(df[['Time']])
    df.drop(columns=['Time', 'Amount'], inplace=True)
    print("[preprocessing] Scaled 'Time' and 'Amount'.")
    return df

# ── Train / Test Split ────────────────────────────────────────────────────────
def split_data(df: pd.DataFrame):
    """Split into features and target, then train/test."""
    X = df.drop(columns=['Class'])
    y = df['Class']
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y
    )
    print(f"[preprocessing] Train size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")
    return X_train, X_test, y_train, y_test

# ── Class Imbalance: SMOTE ────────────────────────────────────────────────────
def apply_smote(X_train: pd.DataFrame, y_train: pd.Series):
    """
    Apply SMOTE (Synthetic Minority Over-sampling Technique) on the training set only.
    SMOTE is never applied to the test set to avoid data leakage.
    """
    sm = SMOTE(random_state=RANDOM_STATE)
    X_resampled, y_resampled = sm.fit_resample(X_train, y_train)
    print(f"[preprocessing] After SMOTE — Class distribution:\n{pd.Series(y_resampled).value_counts()}")
    return X_resampled, y_resampled

# ── Save Artifacts ────────────────────────────────────────────────────────────
def save_splits(X_train, X_test, y_train, y_test):
    """Persist the preprocessed splits so other scripts can load them directly."""
    artifacts = {
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test,
    }
    for name, obj in artifacts.items():
        with open(os.path.join(OUTPUT_DIR, f'{name}.pkl'), 'wb') as f:
            pickle.dump(obj, f)
    print(f"[preprocessing] Saved train/test splits to '{OUTPUT_DIR}/'")

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    df = load_data(DATA_PATH)
    df = scale_features(df)
    X_train, X_test, y_train, y_test = split_data(df)
    X_train_res, y_train_res = apply_smote(X_train, y_train)
    save_splits(X_train_res, X_test, y_train_res, y_test)
    print("[preprocessing] Done.")
