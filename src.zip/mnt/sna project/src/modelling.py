# modelling.py
# Role: Trains and tunes multiple classification models on the preprocessed data.
#        Saves trained models to disk for use by evaluation.py and explainability.py.
# Run order: THIRD — after preprocessing.py and eda.py
# Outputs: trained model files saved to src/models/

import os
import pickle
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, RandomizedSearchCV
from xgboost import XGBClassifier

# ── Configuration ─────────────────────────────────────────────────────────────
RANDOM_STATE = 42
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
MODELS_DIR = os.path.join(os.path.dirname(__file__), 'models')
os.makedirs(MODELS_DIR, exist_ok=True)

# ── Load Preprocessed Data ────────────────────────────────────────────────────
def load_splits():
    """Load train/test splits produced by preprocessing.py."""
    splits = {}
    for name in ['X_train', 'X_test', 'y_train', 'y_test']:
        path = os.path.join(DATA_DIR, f'{name}.pkl')
        with open(path, 'rb') as f:
            splits[name] = pickle.load(f)
    print(f"[modelling] Loaded splits — X_train: {splits['X_train'].shape}, X_test: {splits['X_test'].shape}")
    return splits['X_train'], splits['X_test'], splits['y_train'], splits['y_test']

# ── Save Model ────────────────────────────────────────────────────────────────
def save_model(model, name: str):
    """Persist a trained model to the models/ folder."""
    path = os.path.join(MODELS_DIR, f'{name}.pkl')
    with open(path, 'wb') as f:
        pickle.dump(model, f)
    print(f"[modelling] Saved model: {path}")

# ── Model 1: Logistic Regression (Baseline) ───────────────────────────────────
def train_logistic_regression(X_train, y_train) -> LogisticRegression:
    """
    Logistic Regression as interpretable baseline.
    class_weight='balanced' compensates for residual imbalance after SMOTE.
    """
    print("\n[modelling] Training Logistic Regression (baseline)...")
    model = LogisticRegression(
        max_iter=1000,
        random_state=RANDOM_STATE,
        class_weight='balanced',
        solver='lbfgs'
    )
    model.fit(X_train, y_train)
    print("[modelling] Logistic Regression — Done.")
    return model

# ── Model 2: Random Forest ────────────────────────────────────────────────────
def train_random_forest(X_train, y_train) -> RandomForestClassifier:
    """
    Random Forest with RandomizedSearchCV hyperparameter tuning.
    Tuned parameters: n_estimators, max_depth, min_samples_split, min_samples_leaf.
    CV is stratified to maintain class balance across folds.
    """
    print("\n[modelling] Tuning Random Forest...")
    param_dist = {
        'n_estimators': [100, 200, 300],
        'max_depth': [None, 10, 20, 30],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4],
        'max_features': ['sqrt', 'log2'],
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    rf = RandomForestClassifier(random_state=RANDOM_STATE, class_weight='balanced', n_jobs=-1)
    search = RandomizedSearchCV(
        rf, param_dist,
        n_iter=20,
        scoring='roc_auc',
        cv=cv,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        verbose=1
    )
    search.fit(X_train, y_train)
    best = search.best_estimator_
    print(f"[modelling] Best RF params: {search.best_params_}")
    print(f"[modelling] Best RF CV ROC-AUC: {search.best_score_:.4f}")
    return best

# ── Model 3: XGBoost ──────────────────────────────────────────────────────────
def train_xgboost(X_train, y_train, X_test, y_test) -> XGBClassifier:
    """
    XGBoost with RandomizedSearchCV hyperparameter tuning.
    scale_pos_weight handles residual imbalance in a principled way.
    Tuned parameters: learning_rate, max_depth, n_estimators, subsample, colsample_bytree.
    """
    print("\n[modelling] Tuning XGBoost...")
    fraud_count = int((y_train == 1).sum())
    legit_count = int((y_train == 0).sum())
    scale_pos_weight = legit_count / fraud_count if fraud_count > 0 else 1
    print(f"[modelling] XGB scale_pos_weight: {scale_pos_weight:.2f}")

    param_dist = {
        'n_estimators': [100, 200, 300, 500],
        'max_depth': [3, 5, 7, 9],
        'learning_rate': [0.01, 0.05, 0.1, 0.2],
        'subsample': [0.6, 0.8, 1.0],
        'colsample_bytree': [0.6, 0.8, 1.0],
        'min_child_weight': [1, 3, 5],
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    xgb = XGBClassifier(
        scale_pos_weight=scale_pos_weight,
        use_label_encoder=False,
        eval_metric='auc',
        random_state=RANDOM_STATE,
        n_jobs=-1,
        verbosity=0
    )
    search = RandomizedSearchCV(
        xgb, param_dist,
        n_iter=20,
        scoring='roc_auc',
        cv=cv,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        verbose=1
    )
    search.fit(
        X_train, y_train,
        eval_set=[(X_test, y_test)],
        verbose=False
    )
    best = search.best_estimator_
    print(f"[modelling] Best XGB params: {search.best_params_}")
    print(f"[modelling] Best XGB CV ROC-AUC: {search.best_score_:.4f}")
    return best

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    X_train, X_test, y_train, y_test = load_splits()

    # Train all models
    lr = train_logistic_regression(X_train, y_train)
    save_model(lr, 'logistic_regression')

    rf = train_random_forest(X_train, y_train)
    save_model(rf, 'random_forest')

    xgb = train_xgboost(X_train, y_train, X_test, y_test)
    save_model(xgb, 'xgboost')

    # Save model name registry for use by other scripts
    model_registry = {
        'logistic_regression': lr,
        'random_forest': rf,
        'xgboost': xgb,
    }
    with open(os.path.join(MODELS_DIR, 'all_models.pkl'), 'wb') as f:
        pickle.dump(model_registry, f)

    print("\n[modelling] All models trained and saved.")
    print("[modelling] Done.")
