# src — Credit Card Fraud Detection with XAI (EY Project)

## Project Overview

This project builds an explainable fraud detection system on the `creditcard.csv` dataset using machine learning and XAI techniques (SHAP, LIME). The goal is not only to detect fraudulent transactions but to **explain why** a transaction was flagged — satisfying EY's explainability and accountability requirements.

## Python Version

Python **3.10+** is required.

## Setup

Install all dependencies before running:

```bash
pip install -r requirements.txt
```

## Execution Order

Run the scripts **in the following order**:

### Step 1 — Preprocessing
```bash
python preprocessing.py
```
Loads `../creditcard.csv`, scales Time and Amount, applies SMOTE for class imbalance, and saves train/test splits to `data/`.

### Step 2 — Exploratory Data Analysis
```bash
python eda.py
```
Generates analysis plots (class distribution, feature distributions, correlation heatmap, etc.) and saves them to `figures/`.

### Step 3 — Model Training
```bash
python modelling.py
```
Trains three models: Logistic Regression (baseline), Random Forest, and XGBoost. Hyperparameter tuning is performed via RandomizedSearchCV with 5-fold stratified CV. Saves trained models to `models/`.

### Step 4 — Evaluation
```bash
python evaluation.py
```
Evaluates all models on the held-out test set. Computes Precision, Recall, F1, ROC-AUC, and Average Precision. Saves metrics and plots (confusion matrices, ROC curves, PR curves) to `figures/`.

### Step 5 — Explainability
```bash
python explainability.py
```
Applies SHAP (global + local waterfall plots) and LIME (local explanations) to the best model. Saves XAI figures and feature importance CSV to `figures/`.

## Folder Structure

```
src/
├── preprocessing.py       # Data loading, scaling, SMOTE, train/test split
├── eda.py                 # Exploratory data analysis and figures
├── modelling.py           # Model training and hyperparameter tuning
├── evaluation.py          # Model evaluation and metrics
├── explainability.py      # SHAP and LIME XAI explanations
├── README.md              # This file
├── requirements.txt       # Library dependencies
├── data/                  # Auto-created: preprocessed splits (.pkl)
├── models/                # Auto-created: trained model files (.pkl)
└── figures/               # Auto-created: all plots and CSV metrics
```

## Reproducibility

All random operations use `random_state=42`. Running the scripts in order will produce identical results on any machine with the same Python and library versions.
