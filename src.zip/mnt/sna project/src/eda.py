# eda.py
# Role: Exploratory Data Analysis on the raw creditcard.csv dataset.
#        Produces and saves plots that support Section 2 (Methods) of the technical report.
# Run order: SECOND — after preprocessing.py, before modelling.py
# Outputs: figures saved to src/figures/

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ── Configuration ─────────────────────────────────────────────────────────────
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'creditcard.csv')
FIGURES_DIR = os.path.join(os.path.dirname(__file__), 'figures')
os.makedirs(FIGURES_DIR, exist_ok=True)

sns.set_theme(style='whitegrid', palette='muted')

# ── Load Raw Data ─────────────────────────────────────────────────────────────
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    print(f"[eda] Dataset loaded: {df.shape}")
    return df

# ── Plot 1: Class Distribution ────────────────────────────────────────────────
def plot_class_distribution(df: pd.DataFrame):
    """Bar chart showing the severe class imbalance (fraud vs. legitimate)."""
    counts = df['Class'].value_counts()
    labels = ['Legitimate (0)', 'Fraud (1)']
    colors = ['steelblue', 'tomato']

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    # Count plot
    axes[0].bar(labels, counts.values, color=colors, edgecolor='black')
    axes[0].set_title('Class Distribution (Counts)')
    axes[0].set_ylabel('Number of Transactions')
    for i, v in enumerate(counts.values):
        axes[0].text(i, v + 500, f'{v:,}', ha='center', fontweight='bold')

    # Percentage plot
    pct = counts / counts.sum() * 100
    axes[1].pie(pct.values, labels=labels, colors=colors, autopct='%1.2f%%',
                startangle=90, wedgeprops={'edgecolor': 'black'})
    axes[1].set_title('Class Distribution (Percentage)')

    plt.suptitle('Figure 1: Class Imbalance in the Dataset', fontsize=13, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig1_class_distribution.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[eda] Saved: {path}")

# ── Plot 2: Transaction Amount Distribution ───────────────────────────────────
def plot_amount_distribution(df: pd.DataFrame):
    """Distribution of transaction amounts split by class."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    for ax, cls, label, color in zip(
        axes,
        [0, 1],
        ['Legitimate', 'Fraud'],
        ['steelblue', 'tomato']
    ):
        data = df[df['Class'] == cls]['Amount']
        ax.hist(data, bins=50, color=color, edgecolor='black', alpha=0.8)
        ax.set_title(f'{label} — Amount Distribution')
        ax.set_xlabel('Transaction Amount (€)')
        ax.set_ylabel('Count')
        ax.set_yscale('log')
        ax.axvline(data.median(), color='black', linestyle='--', label=f'Median: {data.median():.2f}')
        ax.legend()

    plt.suptitle('Figure 2: Transaction Amount Distribution by Class', fontsize=13, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig2_amount_distribution.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[eda] Saved: {path}")

# ── Plot 3: Transaction Time Distribution ─────────────────────────────────────
def plot_time_distribution(df: pd.DataFrame):
    """Time of transactions for fraud vs. legitimate to spot temporal patterns."""
    fig, ax = plt.subplots(figsize=(12, 4))
    for cls, label, color in [(0, 'Legitimate', 'steelblue'), (1, 'Fraud', 'tomato')]:
        ax.hist(df[df['Class'] == cls]['Time'] / 3600, bins=48,
                alpha=0.6, label=label, color=color, edgecolor='black')
    ax.set_xlabel('Hours from First Transaction')
    ax.set_ylabel('Count')
    ax.set_title('Figure 3: Transaction Time Distribution by Class', fontsize=13, fontweight='bold')
    ax.legend()
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig3_time_distribution.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[eda] Saved: {path}")

# ── Plot 4: Feature Distributions (V1–V28) ───────────────────────────────────
def plot_feature_distributions(df: pd.DataFrame):
    """Box plots comparing V1-V28 distributions for fraud vs. legitimate transactions."""
    feature_cols = [c for c in df.columns if c.startswith('V')]
    fig, axes = plt.subplots(7, 4, figsize=(20, 28))
    axes = axes.flatten()

    for i, feat in enumerate(feature_cols):
        data_legit = df[df['Class'] == 0][feat]
        data_fraud = df[df['Class'] == 1][feat]
        axes[i].boxplot([data_legit, data_fraud], labels=['Legit', 'Fraud'],
                        patch_artist=True,
                        boxprops=dict(facecolor='steelblue'),
                        medianprops=dict(color='black'))
        # Fraud in red
        axes[i].findobj(plt.Text)
        bp = axes[i].boxplot([data_legit, data_fraud], labels=['Legit', 'Fraud'],
                             patch_artist=True,
                             boxprops=dict(facecolor='steelblue'))
        bp['boxes'][1].set_facecolor('tomato')
        axes[i].set_title(feat)

    plt.suptitle('Figure 4: Feature Distributions — Legitimate vs. Fraud', fontsize=14, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig4_feature_distributions.png')
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"[eda] Saved: {path}")

# ── Plot 5: Correlation Heatmap ───────────────────────────────────────────────
def plot_correlation_heatmap(df: pd.DataFrame):
    """Heatmap of Pearson correlations between all features and the target."""
    corr = df.corr()
    fig, ax = plt.subplots(figsize=(18, 14))
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=False, cmap='coolwarm', center=0,
                linewidths=0.3, ax=ax, cbar_kws={'shrink': 0.8})
    ax.set_title('Figure 5: Feature Correlation Heatmap', fontsize=13, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig5_correlation_heatmap.png')
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"[eda] Saved: {path}")

# ── Plot 6: Top Correlated Features with Target ───────────────────────────────
def plot_top_correlations_with_target(df: pd.DataFrame, top_n: int = 10):
    """Bar chart of the features most correlated with the fraud label."""
    corr_with_target = df.corr()['Class'].drop('Class').abs().sort_values(ascending=False)
    top = corr_with_target.head(top_n)

    fig, ax = plt.subplots(figsize=(10, 5))
    top.plot(kind='bar', ax=ax, color='coral', edgecolor='black')
    ax.set_title(f'Figure 6: Top {top_n} Features Correlated with Fraud (|Pearson r|)',
                 fontsize=12, fontweight='bold')
    ax.set_ylabel('Absolute Correlation')
    ax.set_xlabel('Feature')
    plt.xticks(rotation=45)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig6_top_correlations.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[eda] Saved: {path}")

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    df = load_data(DATA_PATH)

    print("[eda] Basic statistics:")
    print(df.describe())
    print(f"\n[eda] Missing values: {df.isnull().sum().sum()}")
    print(f"[eda] Fraud rate: {df['Class'].mean() * 100:.4f}%")

    plot_class_distribution(df)
    plot_amount_distribution(df)
    plot_time_distribution(df)
    plot_feature_distributions(df)
    plot_correlation_heatmap(df)
    plot_top_correlations_with_target(df)

    print(f"\n[eda] All figures saved to '{FIGURES_DIR}/'")
    print("[eda] Done.")
