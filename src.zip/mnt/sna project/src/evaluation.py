# evaluation.py
# Role: Loads all trained models and evaluates them on the held-out test set.
#        Computes and saves metrics and plots that go into Section 3 of the technical report.
# Run order: FOURTH — after modelling.py
# Outputs: metrics CSV + figures saved to src/figures/

import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    precision_recall_curve,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
)

# ── Configuration ─────────────────────────────────────────────────────────────
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
MODELS_DIR = os.path.join(os.path.dirname(__file__), 'models')
FIGURES_DIR = os.path.join(os.path.dirname(__file__), 'figures')
os.makedirs(FIGURES_DIR, exist_ok=True)

sns.set_theme(style='whitegrid')

MODEL_LABELS = {
    'logistic_regression': 'Logistic Regression (Baseline)',
    'random_forest': 'Random Forest',
    'xgboost': 'XGBoost',
}
COLORS = {
    'logistic_regression': 'gray',
    'random_forest': 'steelblue',
    'xgboost': 'tomato',
}

# ── Load Artifacts ────────────────────────────────────────────────────────────
def load_test_data():
    """Load the held-out test split."""
    with open(os.path.join(DATA_DIR, 'X_test.pkl'), 'rb') as f:
        X_test = pickle.load(f)
    with open(os.path.join(DATA_DIR, 'y_test.pkl'), 'rb') as f:
        y_test = pickle.load(f)
    print(f"[evaluation] Test set: {X_test.shape[0]} samples")
    return X_test, y_test

def load_models():
    """Load all trained models from disk."""
    with open(os.path.join(MODELS_DIR, 'all_models.pkl'), 'rb') as f:
        models = pickle.load(f)
    print(f"[evaluation] Loaded models: {list(models.keys())}")
    return models

# ── Metrics Computation ───────────────────────────────────────────────────────
def compute_metrics(models: dict, X_test, y_test) -> pd.DataFrame:
    """
    Compute classification metrics for each model.
    We prioritise Recall, Precision, F1, and ROC-AUC because fraud detection
    on an imbalanced dataset makes accuracy a misleading metric.
    """
    rows = []
    for name, model in models.items():
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]

        rows.append({
            'Model': MODEL_LABELS[name],
            'Precision': precision_score(y_test, y_pred, zero_division=0),
            'Recall': recall_score(y_test, y_pred, zero_division=0),
            'F1': f1_score(y_test, y_pred, zero_division=0),
            'ROC-AUC': roc_auc_score(y_test, y_prob),
            'Avg Precision (PR-AUC)': average_precision_score(y_test, y_prob),
        })

        print(f"\n[evaluation] {MODEL_LABELS[name]}")
        print(classification_report(y_test, y_pred, target_names=['Legitimate', 'Fraud']))

    df_metrics = pd.DataFrame(rows).set_index('Model')
    metrics_path = os.path.join(FIGURES_DIR, 'metrics_summary.csv')
    df_metrics.to_csv(metrics_path)
    print(f"\n[evaluation] Metrics saved to: {metrics_path}")
    print(df_metrics.round(4).to_string())
    return df_metrics

# ── Plot: Confusion Matrices ──────────────────────────────────────────────────
def plot_confusion_matrices(models: dict, X_test, y_test):
    """Side-by-side confusion matrices for all models."""
    fig, axes = plt.subplots(1, len(models), figsize=(6 * len(models), 5))
    if len(models) == 1:
        axes = [axes]

    for ax, (name, model) in zip(axes, models.items()):
        y_pred = model.predict(X_test)
        cm = confusion_matrix(y_test, y_pred)
        sns.heatmap(
            cm, annot=True, fmt='d', cmap='Blues', ax=ax,
            xticklabels=['Predicted Legit', 'Predicted Fraud'],
            yticklabels=['Actual Legit', 'Actual Fraud'],
            cbar=False
        )
        ax.set_title(MODEL_LABELS[name], fontsize=11, fontweight='bold')

    plt.suptitle('Figure 7: Confusion Matrices on Test Set', fontsize=13, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig7_confusion_matrices.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[evaluation] Saved: {path}")

# ── Plot: ROC Curves ──────────────────────────────────────────────────────────
def plot_roc_curves(models: dict, X_test, y_test):
    """ROC curves for all models on one chart."""
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot([0, 1], [0, 1], 'k--', label='Random Classifier (AUC = 0.50)')

    for name, model in models.items():
        y_prob = model.predict_proba(X_test)[:, 1]
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        auc = roc_auc_score(y_test, y_prob)
        ax.plot(fpr, tpr, color=COLORS[name], lw=2,
                label=f'{MODEL_LABELS[name]} (AUC = {auc:.4f})')

    ax.set_xlabel('False Positive Rate')
    ax.set_ylabel('True Positive Rate (Recall)')
    ax.set_title('Figure 8: ROC Curves — All Models', fontsize=13, fontweight='bold')
    ax.legend(loc='lower right')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig8_roc_curves.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[evaluation] Saved: {path}")

# ── Plot: Precision-Recall Curves ────────────────────────────────────────────
def plot_precision_recall_curves(models: dict, X_test, y_test):
    """
    Precision-Recall curves. More informative than ROC for imbalanced datasets
    as they focus on the minority (fraud) class.
    """
    fig, ax = plt.subplots(figsize=(8, 6))
    baseline = y_test.mean()
    ax.axhline(baseline, color='k', linestyle='--', label=f'Random Classifier (AP = {baseline:.4f})')

    for name, model in models.items():
        y_prob = model.predict_proba(X_test)[:, 1]
        prec, rec, _ = precision_recall_curve(y_test, y_prob)
        ap = average_precision_score(y_test, y_prob)
        ax.plot(rec, prec, color=COLORS[name], lw=2,
                label=f'{MODEL_LABELS[name]} (AP = {ap:.4f})')

    ax.set_xlabel('Recall')
    ax.set_ylabel('Precision')
    ax.set_title('Figure 9: Precision-Recall Curves — All Models', fontsize=13, fontweight='bold')
    ax.legend(loc='upper right')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig9_precision_recall_curves.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[evaluation] Saved: {path}")

# ── Plot: Metrics Comparison Bar Chart ───────────────────────────────────────
def plot_metrics_comparison(df_metrics: pd.DataFrame):
    """Grouped bar chart comparing all metrics across models."""
    df_plot = df_metrics[['Precision', 'Recall', 'F1', 'ROC-AUC']].T
    fig, ax = plt.subplots(figsize=(11, 5))
    df_plot.plot(kind='bar', ax=ax, edgecolor='black', colormap='Set2')
    ax.set_ylim(0, 1.05)
    ax.set_ylabel('Score')
    ax.set_title('Figure 10: Model Performance Comparison', fontsize=13, fontweight='bold')
    ax.legend(title='Model', bbox_to_anchor=(1.01, 1), loc='upper left')
    plt.xticks(rotation=20)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig10_metrics_comparison.png')
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[evaluation] Saved: {path}")

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    X_test, y_test = load_test_data()
    models = load_models()

    df_metrics = compute_metrics(models, X_test, y_test)
    plot_confusion_matrices(models, X_test, y_test)
    plot_roc_curves(models, X_test, y_test)
    plot_precision_recall_curves(models, X_test, y_test)
    plot_metrics_comparison(df_metrics)

    best_model_name = df_metrics['ROC-AUC'].idxmax()
    print(f"\n[evaluation] Best model by ROC-AUC: {best_model_name}")
    print("[evaluation] Done.")
