# explainability.py
# Role: Applies XAI techniques (SHAP and LIME) to the best-performing model to
#        explain both global feature importance and individual transaction predictions.
#        This is the core deliverable for EY — making the fraud detection model transparent.
# Run order: FIFTH — after evaluation.py
# Outputs: SHAP and LIME explanation figures saved to src/figures/

import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
from lime.lime_tabular import LimeTabularExplainer

# ── Configuration ─────────────────────────────────────────────────────────────
RANDOM_STATE = 42
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
MODELS_DIR = os.path.join(os.path.dirname(__file__), 'models')
FIGURES_DIR = os.path.join(os.path.dirname(__file__), 'figures')
os.makedirs(FIGURES_DIR, exist_ok=True)

# Number of individual transactions to explain with LIME
N_LIME_EXAMPLES = 3

# ── Load Artifacts ────────────────────────────────────────────────────────────
def load_data_and_models():
    """Load test data and the best model (XGBoost) for explanation."""
    with open(os.path.join(DATA_DIR, 'X_train.pkl'), 'rb') as f:
        X_train = pickle.load(f)
    with open(os.path.join(DATA_DIR, 'X_test.pkl'), 'rb') as f:
        X_test = pickle.load(f)
    with open(os.path.join(DATA_DIR, 'y_test.pkl'), 'rb') as f:
        y_test = pickle.load(f)
    with open(os.path.join(MODELS_DIR, 'all_models.pkl'), 'rb') as f:
        models = pickle.load(f)

    # Use XGBoost as the primary model to explain (typically best performer)
    best_model = models['xgboost']
    print(f"[explainability] Data loaded — X_test shape: {X_test.shape}")
    return X_train, X_test, y_test, best_model, models

# ── SHAP: Global Explanations ─────────────────────────────────────────────────
def shap_global_explanations(model, X_train, X_test):
    """
    Compute SHAP values using a TreeExplainer (efficient for tree-based models).
    Global explanations answer: 'Which features matter most overall?'

    SHAP (SHapley Additive exPlanations) assigns each feature a contribution
    value for a given prediction, grounded in cooperative game theory.
    """
    print("\n[explainability] Computing SHAP values (this may take a few minutes)...")

    # Use a background sample for efficiency
    background = shap.sample(X_train, 500, random_state=RANDOM_STATE)
    explainer = shap.TreeExplainer(model, background)

    # Use a representative test sample for global analysis
    X_sample = X_test.sample(n=min(2000, len(X_test)), random_state=RANDOM_STATE)
    shap_values = explainer.shap_values(X_sample)

    feature_names = list(X_test.columns)

    # ── Plot A: Summary Plot (Beeswarm) ───────────────────────────────────────
    # Shows direction and magnitude of each feature's effect on fraud probability
    plt.figure(figsize=(10, 8))
    shap.summary_plot(
        shap_values, X_sample,
        feature_names=feature_names,
        show=False,
        plot_type='dot'
    )
    plt.title('Figure 11: SHAP Summary Plot — Global Feature Impact on Fraud Probability',
              fontsize=11, fontweight='bold', pad=20)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig11_shap_summary.png')
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[explainability] Saved: {path}")

    # ── Plot B: Bar Plot (Mean |SHAP|) ────────────────────────────────────────
    # Ranks features by their average absolute contribution
    plt.figure(figsize=(10, 7))
    shap.summary_plot(
        shap_values, X_sample,
        feature_names=feature_names,
        show=False,
        plot_type='bar'
    )
    plt.title('Figure 12: SHAP Feature Importance (Mean |SHAP value|)',
              fontsize=11, fontweight='bold', pad=20)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig12_shap_importance_bar.png')
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[explainability] Saved: {path}")

    return explainer, shap_values, X_sample

# ── SHAP: Local Explanations (Force Plots) ────────────────────────────────────
def shap_local_explanations(explainer, X_test, y_test, shap_values, X_sample):
    """
    Local SHAP explanations for individual fraud transactions.
    Answers: 'Why did the model flag THIS specific transaction as fraud?'
    Essential for EY analysts who need to justify decisions to auditors.
    """
    print("\n[explainability] Generating SHAP local (waterfall) explanations...")

    # Pick fraud cases that the model correctly identified
    y_pred = np.array([1 if p > 0.5 else 0
                       for p in explainer.model.predict_proba(X_test)[:, 1]])
    fraud_idx = np.where((np.array(y_test) == 1) & (y_pred == 1))[0]

    if len(fraud_idx) == 0:
        print("[explainability] No correctly predicted fraud cases found for local explanation.")
        return

    for i, idx in enumerate(fraud_idx[:3]):
        sample = X_test.iloc[[idx]]
        sv = explainer.shap_values(sample)

        plt.figure(figsize=(12, 5))
        shap.waterfall_plot(
            shap.Explanation(
                values=sv[0],
                base_values=explainer.expected_value,
                data=sample.values[0],
                feature_names=list(X_test.columns)
            ),
            show=False
        )
        plt.title(f'Figure {13 + i}: SHAP Waterfall — Fraud Transaction #{idx} '
                  f'(Predicted Probability: {explainer.model.predict_proba(sample)[0, 1]:.3f})',
                  fontsize=10, fontweight='bold', pad=15)
        plt.tight_layout()
        path = os.path.join(FIGURES_DIR, f'fig{13 + i}_shap_waterfall_fraud_{i + 1}.png')
        plt.savefig(path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"[explainability] Saved: {path}")

# ── LIME: Local Explanations ───────────────────────────────────────────────────
def lime_local_explanations(model, X_train, X_test, y_test):
    """
    LIME (Local Interpretable Model-agnostic Explanations) for individual predictions.
    LIME fits a simple linear model locally around the prediction point to approximate
    why the black-box model made a specific decision.
    Provides a complementary perspective to SHAP.
    """
    print("\n[explainability] Generating LIME local explanations...")

    feature_names = list(X_test.columns)
    lime_explainer = LimeTabularExplainer(
        training_data=np.array(X_train),
        feature_names=feature_names,
        class_names=['Legitimate', 'Fraud'],
        mode='classification',
        random_state=RANDOM_STATE
    )

    # Pick correctly predicted fraud cases
    y_prob = model.predict_proba(X_test)[:, 1]
    y_pred = (y_prob > 0.5).astype(int)
    fraud_idx = np.where((np.array(y_test) == 1) & (y_pred == 1))[0]

    if len(fraud_idx) == 0:
        print("[explainability] No correctly predicted fraud cases for LIME.")
        return

    for i, idx in enumerate(fraud_idx[:N_LIME_EXAMPLES]):
        instance = X_test.iloc[idx].values
        exp = lime_explainer.explain_instance(
            instance,
            model.predict_proba,
            num_features=15,
            num_samples=1000
        )

        fig = exp.as_pyplot_figure()
        fig.suptitle(
            f'Figure {16 + i}: LIME Explanation — Fraud Transaction #{idx}\n'
            f'(Fraud Probability: {y_prob[idx]:.3f})',
            fontsize=10, fontweight='bold'
        )
        plt.tight_layout()
        path = os.path.join(FIGURES_DIR, f'fig{16 + i}_lime_fraud_{i + 1}.png')
        plt.savefig(path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"[explainability] Saved: {path}")

# ── SHAP Dependence Plot ──────────────────────────────────────────────────────
def shap_dependence_plots(shap_values, X_sample):
    """
    Dependence plots for the top 3 most important features.
    Shows how a feature's value relates to its SHAP impact on fraud prediction.
    """
    print("\n[explainability] Generating SHAP dependence plots...")

    feature_names = list(X_sample.columns)
    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    top3_idx = np.argsort(mean_abs_shap)[::-1][:3]
    top3_features = [feature_names[i] for i in top3_idx]

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    for ax, feat in zip(axes, top3_features):
        feat_idx = feature_names.index(feat)
        ax.scatter(
            X_sample[feat].values,
            shap_values[:, feat_idx],
            c=shap_values[:, feat_idx],
            cmap='RdBu_r', alpha=0.4, s=10
        )
        ax.axhline(0, color='black', linestyle='--', linewidth=0.8)
        ax.set_xlabel(feat)
        ax.set_ylabel('SHAP value (impact on fraud probability)')
        ax.set_title(f'Dependence: {feat}')

    fig.suptitle('Figure 19: SHAP Dependence Plots — Top 3 Most Important Features',
                 fontsize=12, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, 'fig19_shap_dependence.png')
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[explainability] Saved: {path}")

# ── XAI Summary: Business Interpretation ─────────────────────────────────────
def save_feature_importance_table(shap_values, X_sample):
    """
    Save a CSV table ranking features by mean |SHAP| value.
    This is the business-readable summary EY analysts can use directly.
    """
    feature_names = list(X_sample.columns)
    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    df_importance = pd.DataFrame({
        'Feature': feature_names,
        'Mean |SHAP value|': mean_abs_shap
    }).sort_values('Mean |SHAP value|', ascending=False).reset_index(drop=True)

    df_importance['Rank'] = df_importance.index + 1
    path = os.path.join(FIGURES_DIR, 'shap_feature_importance.csv')
    df_importance.to_csv(path, index=False)
    print(f"\n[explainability] Feature importance table saved: {path}")
    print(df_importance.head(10).to_string(index=False))

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    X_train, X_test, y_test, best_model, models = load_data_and_models()

    # Global SHAP explanations
    explainer, shap_values, X_sample = shap_global_explanations(best_model, X_train, X_test)

    # Local SHAP explanations (individual transactions)
    shap_local_explanations(explainer, X_test, y_test, shap_values, X_sample)

    # SHAP dependence plots for top features
    shap_dependence_plots(shap_values, X_sample)

    # LIME local explanations (complementary to SHAP)
    lime_local_explanations(best_model, X_train, X_test, y_test)

    # Business-readable feature importance table
    save_feature_importance_table(shap_values, X_sample)

    print(f"\n[explainability] All XAI figures saved to '{FIGURES_DIR}/'")
    print("[explainability] Done.")
